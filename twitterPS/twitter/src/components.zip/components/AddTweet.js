import { useState } from "react";
export default function AddTweet(props) {
	let [currentText, setCurrentText] = useState("");

	function handleTweetInput(e) {
		setCurrentText(e.target.value);
	}

	function handleAddTweet(e) {
		props.addTweetToList(currentText);
	}
	return (
		<div className="createTweet">
			<div className="tweetInputFields">
				<input
					onChange={handleTweetInput}
					type="textarea"
					className="tweetInput"
					cols={5}
				/>
				<button id="tweetButton" onClick={handleAddTweet}>
					Tweet
				</button>
			</div>
		</div>
	);
}

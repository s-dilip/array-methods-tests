import { useState } from "react";
import { fields } from "../defaultUser.js";

export default function EditProfile(props) {
	let [isFormVisible, setIsFormVisible] = useState(false);
	let [newUserInfo, setNewUserInfo] = useState({});

	function editFields(event) {
		let updatedUser = {
			...newUserInfo,
			[event.target.name]: event.target.value,
		};
		setNewUserInfo(updatedUser);
	}

	function handleFormSubmit(e) {
		e.preventDefault();
		props.handleUserInfoChange(newUserInfo);
	}

	// function handleNameChange(e) {
	// 	// setUserName(e.target.value);
	// }

	// function handleDisplayNameChange(e) {
	// 	// setDisplayName(e.target.value);
	// }

	function toggleProfileEdit(e) {
		const visibility = !isFormVisible;
		setIsFormVisible(visibility);
	}

	function displayForm() {
		return (
			<div id="editProfileWrapper">
				<form
					id="editProfileForm"
					onSubmit={handleFormSubmit}
					// onKeyPress={editFields}
				>
					{Object.keys(fields).map((key) => {
						return (
							<div key={`${key}Input`}>
								<label>{fields[key]}</label>
								<input
									className="profileEditFields"
									name={key}
									type="text"
									onChange={editFields}
								/>
								<br />
							</div>
						);
					})}
					<button type="submit">Update Details</button>
				</form>
			</div>
		);
	}

	return (
		<div id="editProfile">
			<button onClick={toggleProfileEdit}>Edit Profile</button>
			{isFormVisible ? displayForm() : ""}
		</div>
	);
}
